skip_if_not_using_local_queue <- function() {
  skip_on_cran()
  skip_if_not_installed("thor")
}
