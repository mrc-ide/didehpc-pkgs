library(testthat)
library(didehpc)

test_check("didehpc")
