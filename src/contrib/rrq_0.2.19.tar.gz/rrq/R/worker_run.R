worker_run_task <- function(worker, task_id) {
  task <- worker_run_task_start(worker, task_id)
  if (task$separate_process) {
    res <- worker_run_task_separate_process(task, worker)
  } else {
    res <- worker_run_task_local(task, worker)
  }
  task_status <- if (res$success) TASK_COMPLETE else TASK_ERROR
  worker_queue_dependencies(worker, task_id, task_status)
  worker_run_task_cleanup(worker, task_status, res$value)
}


worker_run_task_local <- function(task, worker) {
  e <- expression_restore_locals(task, worker$envir, worker$db)
  withCallingHandlers(
    expression_eval_safely(task$expr, e),
    progress = function(e)
      task_progress_update(unclass(e), worker, FALSE))
}


worker_run_task_separate_process <- function(task, worker) {
  redis_config <- worker$con$config()
  queue_id <- worker$keys$queue_id
  worker_id <- worker$name
  task_id <- task$id
  worker$log("REMOTE", task_id)
  callr::r(function(redis_config, queue_id, worker_id, task_id)
    remote_run_task(redis_config, queue_id, worker_id, task_id),
    list(redis_config, queue_id, worker_id, task_id),
    package = "rrq")
}


remote_run_task <- function(redis_config, queue_id, worker_id, task_id) {
  worker_name <- sprintf("%s_%s", worker_id, ids::random_id(bytes = 4))
  con <- redux::hiredis(config = redis_config)
  worker <- rrq_worker_$new(con, queue_id, worker_name = worker_name,
                            register = FALSE)
  task <- bin_to_object(con$HGET(worker$keys$task_expr, task_id))

  ## Ensures that the worker and task will be found by
  ## rrq_task_progress_update
  cache$active_worker <- worker
  worker$active_task <- list(task_id = task_id)

  worker_run_task_local(task, worker)
}


worker_run_task_start <- function(worker, task_id) {
  keys <- worker$keys
  name <- worker$name
  dat <- worker$con$pipeline(
    worker_log(redis, keys, "TASK_START", task_id, worker$verbose),
    redis$HSET(keys$worker_status, name,      WORKER_BUSY),
    redis$HSET(keys$worker_task,   name,      task_id),
    redis$HSET(keys$task_worker,   task_id,   name),
    redis$HSET(keys$task_status,   task_id,   TASK_RUNNING),
    redis$HGET(keys$task_complete, task_id),
    redis$HGET(keys$task_local,    task_id),
    redis$HGET(keys$task_expr,     task_id))

  ## This holds the bits of worker state we might need to refer to
  ## later for a running task:
  worker$active_task <- list(task_id = task_id, key_complete = dat[[6]])

  ## And this holds the data used in worker_run_task_to actually run
  ## the task
  ret <- bin_to_object(dat[[8]])
  ret$separate_process <- dat[[7]] == "FALSE" # NOTE: not a coersion
  ret$id <- task_id
  ret
}


worker_run_task_cleanup <- function(worker, status, value) {
  task <- worker$active_task
  task_id <- task$task_id
  key_complete <- task$key_complete

  keys <- worker$keys
  name <- worker$name
  log_status <- paste0("TASK_", status)

  worker$con$pipeline(
    redis$HSET(keys$task_result,    task_id,  object_to_bin(value)),
    redis$HSET(keys$task_status,    task_id,  status),
    redis$HSET(keys$worker_status,  name,     WORKER_IDLE),
    redis$HDEL(keys$worker_task,    name),
    if (!is.null(key_complete)) {
      redis$RPUSH(key_complete, task_id)
    },
    worker_log(redis, keys, log_status, task_id, worker$verbose))

  worker$active_task <- NULL
  invisible()
}
