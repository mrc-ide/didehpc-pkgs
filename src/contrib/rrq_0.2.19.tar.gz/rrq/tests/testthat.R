library(testthat)
library(rrq)

test_check("rrq")
