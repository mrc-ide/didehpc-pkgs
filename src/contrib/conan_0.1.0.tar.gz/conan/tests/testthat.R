library(testthat)
library(conan)

test_check("conan")
